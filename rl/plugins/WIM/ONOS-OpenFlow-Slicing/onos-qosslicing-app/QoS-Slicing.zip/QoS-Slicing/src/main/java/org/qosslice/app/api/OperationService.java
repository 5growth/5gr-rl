package org.qosslice.app.api;


public interface OperationService {
    /**
     * Submits a QosSlice operation.
     *
     */
    void submit(QosSliceOperation qoSSlicingOperation);
}
