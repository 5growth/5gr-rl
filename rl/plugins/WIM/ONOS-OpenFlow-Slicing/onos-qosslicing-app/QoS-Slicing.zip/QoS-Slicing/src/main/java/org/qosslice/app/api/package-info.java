/**
 * APIs for QosSlice.
 */

package org.qosslice.app.api;