/**
 * Implementation CLI for VPLS services.
 */

package org.qosslice.app.cli;