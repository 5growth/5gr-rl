/*
 * Copyright 2017-present Open Networking Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.onosproject.p4slicing.slicer;

import com.google.common.collect.Lists;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ReferenceCardinality;
import org.onlab.packet.IpAddress;
import org.onosproject.core.ApplicationId;
import org.onosproject.core.CoreService;
import org.onosproject.net.DeviceId;
import org.onosproject.net.Host;
import org.onosproject.net.Link;
import org.onosproject.net.Path;
import org.onosproject.net.PortNumber;
import org.onosproject.net.flow.DefaultFlowRule;
import org.onosproject.net.flow.DefaultTrafficSelector;
import org.onosproject.net.flow.DefaultTrafficTreatment;
import org.onosproject.net.flow.FlowRule;
import org.onosproject.net.flow.FlowRuleService;
import org.onosproject.net.flow.criteria.PiCriterion;
import org.onosproject.net.host.HostEvent;
import org.onosproject.net.host.HostListener;
import org.onosproject.net.host.HostService;
import org.onosproject.net.pi.model.PiActionId;
import org.onosproject.net.pi.model.PiActionParamId;
import org.onosproject.net.pi.model.PiMatchFieldId;
import org.onosproject.net.pi.model.PiTableId;
import org.onosproject.net.pi.runtime.PiAction;
import org.onosproject.net.pi.runtime.PiActionParam;
import org.onosproject.net.topology.Topology;
import org.onosproject.net.topology.TopologyService;
import org.slf4j.Logger;

import java.util.Collections;
import java.util.List;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

import static org.slf4j.LoggerFactory.getLogger;

/**
 * MyTunnel application which provides forwarding between each pair of hosts via
 * MyTunnel protocol as defined in mytunnel.p4.
 * <p>
 * The app works by listening for host events. Each time a new host is
 * discovered, it provisions a tunnel between that host and all the others.
 */
@Component(immediate = true, service = P4SlicerService.class)
public class P4Slicer implements P4SlicerService {

    private static final String APP_NAME = "org.onosproject.p4slicing.slicer";

    // Default priority used for flow rules installed by this app.
    private static final int FLOW_RULE_PRIORITY = 100;

    private ApplicationId appId;

    private static final Logger log = getLogger(P4Slicer.class);

    //--------------------------------------------------------------------------
    // ONOS core services needed by this application.
    //--------------------------------------------------------------------------

    @Reference(cardinality = ReferenceCardinality.MANDATORY)
    private FlowRuleService flowRuleService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY)
    private CoreService coreService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY)
    private TopologyService topologyService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY)
    private HostService hostService;

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------

    private HashMap<Integer, List<DeviceId>> tunnelsMap = new HashMap<Integer, List<DeviceId>>();

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------

    @Activate
    public void activate() {
        // Register app and event listeners.
        log.info("Starting...");
        appId = coreService.registerApplication(APP_NAME);
        log.info("STARTED", appId.id());
    }

    @Deactivate
    public void deactivate() {
        // Remove listeners and clean-up flow rules.
        log.info("Stopping...");
        flowRuleService.removeFlowRulesById(appId);
        log.info("STOPPED");
    }

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------

    @Override
    public void setSlice(String srcVnf, String dstVnf, int tunId, List<DeviceId> newTunnel, int maxCapacity) {
        instantiateTunnel(tunId, newTunnel, maxCapacity);
        instantiateSlice(tunId, srcVnf, dstVnf);
    }

    @Override
    public void instantiateTunnel(int tunId, List<DeviceId> newTunnel, int maxCapacity){
      tunnelsMap.put(tunId, newTunnel);
      addTunnel(tunId, maxCapacity, true);
    }

    @Override
    public void instantiateSlice(int tunId, String srcVnf, String dstVnf) {
      addSlice(tunId, srcVnf, dstVnf, true);
    }

    @Override
    public void updateTunnel(int tunId, List<DeviceId> newTunnel, int maxCapacity) {
      //TODO: Fix old capacity
      addTunnel(tunId, maxCapacity, false);
      tunnelsMap.put(tunId, newTunnel);
      addTunnel(tunId, maxCapacity, true);
    }

    @Override
    public void updateSlice(int oldTunId, int newTunId, String srcVnfId, String dstVnfId) {
      addSlice(oldTunId, srcVnfId, dstVnfId, false);
      addSlice(newTunId, srcVnfId, dstVnfId, true);
    }

    private void addTunnel(int tunId, int maxCapacity, boolean create){
      List<DeviceId> tunnel = tunnelsMap.get(tunId);
      createTunnel(tunId, tunnel, maxCapacity, create);
      //Bidirectional tunnel
      Collections.reverse(tunnel);
      createTunnel(tunId+1, tunnel, maxCapacity, create);
      //Set the normal direction again
      Collections.reverse(tunnel);
    }

    private void createTunnel(int tunId, List<DeviceId> tunnel, int maxCapacity, boolean create) {
      for(int i=0; i<(tunnel.size()-1); ++i){
        DeviceId srcSwitch = tunnel.get(i);
        DeviceId dstSwitch = tunnel.get(i+1);
        Link link = getLinkFromPath(srcSwitch, dstSwitch);
        insertTunnelForwardRule(srcSwitch, link.src().port(), tunId, false, create);
        //Set meters
        insertMeterTableRule(srcSwitch, tunId, getMeterFromQosPolicy(maxCapacity), create);
        //Set the meter filer -> if p4 meter tag != 0 then drop the packet
        insertMeterFilterRule(srcSwitch, 0, create);
      }
    }

    private void addSlice(int sliceId, String srcVnfId, String dstVnfId, boolean create){
      //TODO: get host from vnfId, so far vnfId == ip address (for demo purposes).
      //Insert ingress flow rule:
      List<DeviceId> tunnel = tunnelsMap.get(sliceId);
      createSlice(sliceId, srcVnfId, dstVnfId, tunnel, create);
      //Bidirectional slice
      Collections.reverse(tunnel);
      createSlice(sliceId+1, dstVnfId, srcVnfId, tunnel, create);
      //Set the normal direction again
      Collections.reverse(tunnel);
    }

    private void createSlice(int sliceId,
                              String srcVnfId,
                              String dstVnfId,
                              List<DeviceId> tunnel,
                              boolean create){

      Host srcHost = getHostFromVnfId(srcVnfId);
      DeviceId srcSwitch = srcHost.location().deviceId();
      IpAddress dstIpAddr = IpAddress.valueOf(dstVnfId);
      int tunId = sliceId; //FIX: differentiate between sliceId and tunId
      //Flow rule that adds the tunnel id header
      insertTunnelIngressRule(srcSwitch, dstIpAddr, tunId, create);
      //Flow rule that forwards to the first switch of the tunnel
      DeviceId nxtSwitch = tunnel.get(0);
      Link link = getLinkFromPath(srcSwitch, nxtSwitch);
      insertTunnelForwardRule(srcSwitch, link.src().port(), tunId, false, create);

      Host dstHost = getHostFromVnfId(dstVnfId);
      //Flow rule from the last switch of the tunnel to the NFV-PoP switch.
      DeviceId lastSwitch = tunnel.get(tunnel.size()-1);
      DeviceId dstSwitch = dstHost.location().deviceId();
      link = getLinkFromPath(lastSwitch, dstSwitch);
      insertTunnelForwardRule(lastSwitch, link.src().port(), tunId, false, create);

      // Tunnel egress rule.
      PortNumber egressSwitchPort = dstHost.location().port();
      insertTunnelForwardRule(dstSwitch, egressSwitchPort, tunId, true, create);

        //Set the meter filer -> if p4 meter tag != 0 then drop the packet
        insertMeterFilterRule(srcSwitch, 0, create);
    }

    private Host getHostFromVnfId(String vnfId){
      Set<Host> hosts = hostService.getHostsByIp(IpAddress.valueOf(vnfId));
      for(Host host: hosts){
        return host; //Unique IP address
      }
      return null;
    }

    private Link getLinkFromPath(DeviceId srcSwitch, DeviceId dstSwitch){
      Topology topo = topologyService.currentTopology();
      Set<Path> paths = topologyService.getPaths(topo, srcSwitch, dstSwitch);
      //TODO: check if path length from srcSwitch
      //and dstSwitch is equal to 1 (directly connected)
      for(Path path: paths){
        return path.links().get(0);
      }
      return null;
    }

    private int getMeterFromQosPolicy(int maxCapacity) {
        int meterId;
        //TODO: set real values
        if(maxCapacity >= 500)
            meterId = 3;
        else
            meterId = 1;
        return meterId;
    }

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------



    /**
     * Generates and insert a flow rule to perform the tunnel INGRESS function
     * for the given switch, destination IP address and tunnel ID.
     *
     * @param switchId  switch ID
     * @param dstIpAddr IP address to forward inside the tunnel
     * @param tunId     tunnel ID
     */
    private void insertTunnelIngressRule(DeviceId switchId,
                                         IpAddress dstIpAddr,
                                         int tunId,
                                         boolean create) {


        PiTableId tunnelIngressTableId = PiTableId.of("c_ingress.t_tunnel_ingress");

        // Longest prefix match on IPv4 dest address.
        PiMatchFieldId ipDestMatchFieldId = PiMatchFieldId.of("hdr.ipv4.dst_addr");
        PiCriterion match = PiCriterion.builder()
                .matchLpm(ipDestMatchFieldId, dstIpAddr.toOctets(), 32)
                .build();

        PiActionParam tunIdParam = new PiActionParam(PiActionParamId.of("tun_id"), tunId);

        PiActionId ingressActionId = PiActionId.of("c_ingress.my_tunnel_ingress");
        PiAction action = PiAction.builder()
                .withId(ingressActionId)
                .withParameter(tunIdParam)
                .build();

        log.info("Inserting INGRESS rule on switch {}: table={}, match={}, action={}",
                 switchId, tunnelIngressTableId, match, action);

        insertPiFlowRule(switchId, tunnelIngressTableId, match, action, create);
    }

    /**
     * Generates and insert a flow rule to perform the tunnel FORWARD/EGRESS
     * function for the given switch, output port address and tunnel ID.
     *
     * @param switchId switch ID
     * @param outPort  output port where to forward tunneled packets
     * @param tunId    tunnel ID
     * @param isEgress if true, perform tunnel egress action, otherwise forward
     *                 packet as is to port
     */
    private void insertTunnelForwardRule(DeviceId switchId,
                                         PortNumber outPort,
                                         int tunId,
                                         boolean isEgress,
                                         boolean create) {

        PiTableId tunnelForwardTableId = PiTableId.of("c_ingress.t_tunnel_fwd");

        // Exact match on tun_id
        PiMatchFieldId tunIdMatchFieldId = PiMatchFieldId.of("hdr.my_tunnel.tun_id");
        PiCriterion match = PiCriterion.builder()
                .matchExact(tunIdMatchFieldId, tunId)
                .build();

        // Action depend on isEgress parameter.
        // if true, perform tunnel egress action on the given outPort, otherwise
        // simply forward packet as is (set_out_port action).
        PiActionParamId portParamId = PiActionParamId.of("port");
        PiActionParam portParam = new PiActionParam(portParamId, (short) outPort.toLong());

        final PiAction action;
        if (isEgress) {
            // Tunnel egress action.
            // Remove MyTunnel header and forward to outPort.
            PiActionId egressActionId = PiActionId.of("c_ingress.my_tunnel_egress");
            action = PiAction.builder()
                    .withId(egressActionId)
                    .withParameter(portParam)
                    .build();
        } else {
            // Tunnel transit action.
            // Forward the packet as is to outPort.
            PiActionId egressActionId = PiActionId.of("c_ingress.set_out_port");
            action = PiAction.builder()
                    .withId(egressActionId)
                    .withParameter(portParam)
                    .build();
        }

        log.info("Inserting {} rule on switch {}: table={}, match={}, action={}",
                 isEgress ? "EGRESS" : "TRANSIT",
                 switchId, tunnelForwardTableId, match, action);

        insertPiFlowRule(switchId, tunnelForwardTableId, match, action, create);
    }


    /**
     * Generates and insert a flow rule to perform the tunnel IPV4 forwarding
     * for the given switch, destination IP address and tunnel ID.
     *
     * @param switchId  switch ID
     * @param dstIpAddr IP address to forward
     * @param meterId   Meter Id
     */
    private void insertMeterTableRule(DeviceId switchId,
                                      int tunId,
                                      int meterId,
                                      boolean create) {


        PiTableId meterTableId = PiTableId.of("c_ingress.m_table");

        // Exact match on tun_id
        PiMatchFieldId tunIdMatchFieldId = PiMatchFieldId.of("hdr.my_tunnel.tun_id");
        PiCriterion match = PiCriterion.builder()
                .matchExact(tunIdMatchFieldId, tunId)
                .build();

        PiActionParam meterIdParam = new PiActionParam(PiActionParamId.of("meter_id"), meterId);

        PiActionId meterActionId = PiActionId.of("c_ingress.m_action");
        PiAction action = PiAction.builder()
                .withId(meterActionId)
                .withParameter(meterIdParam)
                .build();

        log.info("Inserting Meter Table rule on switch {}: table={}, match={}, action={}",
                switchId, meterTableId, match, action);

        insertPiFlowRule(switchId, meterTableId, match, action, create);
    }

    /**
     * Generates and insert a flow rule to perform the tunnel IPV4 forwarding
     * for the given switch, destination IP address and tunnel ID.
     *
     * @param switchId  switch ID
     * @param meterTag  Match meter tag
     */
    private void insertMeterFilterRule(DeviceId switchId,
                                       int meterTag,
                                       boolean create) {


        PiTableId meterTableId = PiTableId.of("c_ingress.m_filter");

        // Longest prefix match on IPv4 dest address.
        PiMatchFieldId meterTagMatchFieldId = PiMatchFieldId.of("meta.meter_tag");
        PiCriterion match = PiCriterion.builder()
                .matchExact(meterTagMatchFieldId, meterTag)
                .build();

        PiActionId meterFilterActionId;
        if(meterTag == 1)
            meterFilterActionId = PiActionId.of("c_ingress.set_ecn");
        else
            meterFilterActionId = PiActionId.of("NoAction");
        PiAction action = PiAction.builder()
                .withId(meterFilterActionId)
                .build();

        log.info("Inserting Meter Filter rule on switch {}: table={}, match={}, action={}",
                switchId, meterTableId, match, action);

        insertPiFlowRule(switchId, meterTableId, match, action, create);
    }

    /**
     * Inserts a flow rule in the system that using a PI criterion and action.
     *
     * @param switchId    switch ID
     * @param tableId     table ID
     * @param piCriterion PI criterion
     * @param piAction    PI action
     */
    private void insertPiFlowRule(DeviceId switchId, PiTableId tableId,
                                  PiCriterion piCriterion, PiAction piAction, boolean create) {
        FlowRule rule = DefaultFlowRule.builder()
                .forDevice(switchId)
                .forTable(tableId)
                .fromApp(appId)
                .withPriority(FLOW_RULE_PRIORITY)
                .makePermanent()
                .withSelector(DefaultTrafficSelector.builder()
                                      .matchPi(piCriterion).build())
                .withTreatment(DefaultTrafficTreatment.builder()
                                       .piTableAction(piAction).build())
                .build();
        if(create){
          flowRuleService.applyFlowRules(rule);
        } else {
          flowRuleService.removeFlowRules(rule);
        }
    }
}
