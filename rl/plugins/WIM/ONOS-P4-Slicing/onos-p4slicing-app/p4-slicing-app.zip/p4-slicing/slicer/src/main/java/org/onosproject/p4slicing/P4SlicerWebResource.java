/*
 * Copyright 2015-present Open Networking Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Originally created by Pengfei Lu, Network and Cloud Computing Laboratory, Dalian University of Technology, China
 * Advisers: Keqiu Li, Heng Qi and Haisheng Yu
 * This work is supported by the State Key Program of National Natural Science of China(Grant No. 61432002)
 * and Prospective Research Project on Future Networks in Jiangsu Future Networks Innovation Institute.
 */
package org.onosproject.p4slicing;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.onlab.packet.IPv4;
import org.onlab.packet.Ip4Prefix;
import org.onlab.packet.MacAddress;
import org.onosproject.rest.AbstractWebResource;
import org.onosproject.p4slicing.slicer.P4SlicerService;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.ArrayList;
import org.onosproject.net.DeviceId;
import org.slf4j.Logger;

import static org.onlab.util.Tools.readTreeFromStream;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * Manage ACL rules.
 */
@Path("")
public class P4SlicerWebResource extends AbstractWebResource {

    private static final Logger log = getLogger(P4SlicerWebResource.class);
    /**
     * Get all ACL rules.
     * Returns array of all ACL rules.
     *
     * @return 200 OK
     */
    @GET
    @Path("tunnel")
    public Response getTunnels() {
        //TODO
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode root = mapper.createObjectNode();
        ArrayNode arrayNode = mapper.createArrayNode();
        root.set("tunnel", arrayNode);
        return Response.ok(root.toString(), MediaType.APPLICATION_JSON_TYPE).build();
    }

    @POST
    @Path("tunnel")
    public Response putTunnel(InputStream stream) {
      JsonNode node;
        try {
            node = readTreeFromStream(mapper(), stream);
        } catch (IOException e) {
            throw new IllegalArgumentException("Unable to parse Tunnel request", e);
        }
        //TODO: validations
        int tunId = node.path("tun_id").asInt();
        JsonNode path = node.path("path");
        int maxCapacity = node.path("max_capacity").asInt();

        get(P4SlicerService.class).instantiateTunnel(tunId, nodeListToDeviceIdList(path), maxCapacity);
        return Response.ok("").build();
    }

    @PUT
    @Path("tunnel")
    public Response postTunnel(InputStream stream) {
      JsonNode node;
        try {
            node = readTreeFromStream(mapper(), stream);
        } catch (IOException e) {
            throw new IllegalArgumentException("Unable to parse Tunnel request", e);
        }
        //TODO: validations
        int tunId = node.path("tun_id").asInt();
        JsonNode path = node.path("path");
        int maxCapacity = node.path("max_capacity").asInt();

        get(P4SlicerService.class).updateTunnel(tunId, nodeListToDeviceIdList(path), maxCapacity);
        return Response.ok("").build();
    }

    @POST
    @Path("slice")
    public Response postSlice(InputStream stream) {
      JsonNode node;
        try {
            node = readTreeFromStream(mapper(), stream);
        } catch (IOException e) {
            throw new IllegalArgumentException("Unable to parse Slice request", e);
        }
        //TODO: validations
        String srcVnf = node.path("srcEndpoint").asText();
        String dstVnf = node.path("dstEndpoint").asText();
        int tunId = node.path("sliceId").asInt();
        JsonNode path = node.path("switchIdentifiers");
        int maxCapacity = node.path("maxCapacity").asInt();
        //int burstSize = node.path("burst_size").asInt();

        get(P4SlicerService.class).setSlice(srcVnf, dstVnf, tunId, nodeListToDeviceIdList(path), maxCapacity);
        return Response.ok("").build();
    }

    @PUT
    @Path("slice")
    public Response putSlice(InputStream stream) {
      JsonNode node;
        try {
            node = readTreeFromStream(mapper(), stream);
        } catch (IOException e) {
            throw new IllegalArgumentException("Unable to parse Slice request", e);
        }
        //TODO: validations
        int currentTunId = node.path("current_tun_id").asInt();
        int newTunId = node.path("new_tun_id").asInt();
        String srcVnf = node.path("src_vnf").asText();
        String dstVnf = node.path("dst_vnf").asText();

        get(P4SlicerService.class).updateSlice(currentTunId, newTunId, srcVnf, dstVnf);
        return Response.ok("").build();
    }

    private List<DeviceId> nodeListToDeviceIdList(JsonNode path){
      List<DeviceId> devIdList = new ArrayList<>();
      for(JsonNode deviceId: path){
        devIdList.add(DeviceId.deviceId(deviceId.asText()));
      }
      return devIdList;
    }

}
