# Copyright 2018 b<>com. All rights reserved.
# This software is the confidential intellectual property of b<>com. You shall
# not disclose it and shall use it only in accordance with the terms of the
# license agreement you entered into with b<>com.
# IDDN number:
#
# -*- coding: utf-8 -*-

import asyncio
import concurrent
import logging
import multiprocessing
import queue
import threading
import typing as t

import conveyer

from apisdk import job

LOG = logging.getLogger(__name__)


class Service:

    def __init__(self, **kwargs):
        self.kwargs = kwargs

    def start(self) -> None:
        """Start the service."""
        raise NotImplementedError()

    def stop(self) -> None:
        """Stop the service even if still running."""
        raise NotImplementedError()

    def wait(self) -> None:
        """Wait for the service to complete."""
        raise NotImplementedError()

    def get_health_status(self) -> conveyer.HealthStatus:
        raise NotImplementedError()


class ThreadedService(threading.Thread, Service):

    def __init__(self, **kwargs):
        Service.__init__(self, **kwargs)
        threading.Thread.__init__(self)
        self.daemon = True
        self._stop_event = threading.Event()
        self.error_queue = queue.Queue()

    def run(self) -> None:
        raise NotImplementedError()

    def wait(self) -> None:
        """Wait for the service to complete."""
        self.join()

    def stop(self):
        self._stop_event.set()

    def get_health_status(self) -> conveyer.HealthStatus:
        status = conveyer.HealthStatus(status=conveyer.HealthStatus.OK)

        if not self.is_alive():
            error = "unknown"
            try:
                error = self.error_queue.get_nowait()
                # Requeue the exception for the next healthcheck
                self.error_queue.put(error)
            except Exception:
                pass
            status.status = conveyer.HealthStatus.ERROR
            status.reason = str(error)

        return status


class AsyncIOEventConsumer(ThreadedService):
    """AsyncIO I/O loop."""

    def __init__(
            self,
            handlers: t.List[t.Callable[[], job.AsyncJob]],
            **handler_params) -> None:
        super().__init__()
        self.daemon = True

        self._handler_params = handler_params
        self._consumer = None

        self._event_handlers = handlers

        self.executor = concurrent.futures.ThreadPoolExecutor()
        self.event_loop = asyncio.get_event_loop()

    def run(self):
        self.event_loop.set_default_executor(self.executor)
        for handler_factory in self._event_handlers:
            handler = handler_factory(**self.handler_params)
            self.event_loop.create_task(handler.run())
        self.event_loop.run_forever()

    def stop(self):
        self.executor.shutdown(wait=False)
        self.event_loop.stop()
        self.event_loop.close()


class ProcessService(multiprocessing.Process, Service):

    def __init__(self, **kwargs):
        Service.__init__(self, **kwargs)
        multiprocessing.Process.__init__(self)
        self.daemon = True
        self._stop_event = multiprocessing.Event()
        self.error_queue = multiprocessing.Queue(1)

    def run(self) -> None:
        raise NotImplementedError()

    def wait(self) -> None:
        """Wait for the service to complete."""
        self.join()

    def stop(self):
        self._stop_event.set()

    def get_health_status(self) -> conveyer.HealthStatus:
        status = conveyer.HealthStatus(status=conveyer.HealthStatus.OK)

        if not self.is_alive():
            error = "unknown"
            try:
                error = self.error_queue.get_nowait()
                # Requeue the exception for the next healthcheck
                self.error_queue.put(error)
            except Exception:
                pass
            status.status = conveyer.HealthStatus.ERROR
            status.reason = str(error)

        return status


class ServiceManager:

    def __init__(self, services: t.List[t.Type[Service]], **kwargs):
        self.services = {svc: svc(**kwargs) for svc in services}

    def start(self):
        for svc_cls, svc in self.services.items():
            LOG.debug("Service to be started: %s", svc_cls)
            svc.start()
            LOG.debug("Started service: %s", svc_cls)
        LOG.info("Running services: %s",
                 [k.__name__ for k in self.services.keys()])
        for svc_cls, svc in self.services.items():
            svc.wait()

    def stop(self):
        for svc_cls, svc in self.services.items():
            LOG.debug("Service to be stopped: %s", svc_cls)
            svc.stop()
        LOG.info("Stopped services: %s",
                 [k.__name__ for k in self.services.keys()])

    def get_health_status(self) -> conveyer.HealthStatus:
        status = conveyer.HealthStatus.OK
        reasons = dict()
        for svc_cls, svc in self.services.items():
            svc_status = svc.get_health_status()
            if svc_status.status != conveyer.HealthStatus.OK:
                status = svc_status.status
                reasons[str(svc_cls.__name__)] = svc_status.reason

        return conveyer.HealthStatus(
            status=status,
            reason=str(reasons) if reasons else None,
        )
