# Copyright 2018 b<>com. All rights reserved.
# This software is the confidential intellectual property of b<>com. You shall
# not disclose it and shall use it only in accordance with the terms of the
# license agreement you entered into with b<>com.
# IDDN number:
#
# -*- coding: utf-8 -*-

import typing as t

import conveyer

from apisdk import schema


class ResourceNotification(conveyer.OutgoingMessage):

    def __init__(self,
                 producer: conveyer.MessageProducer,
                 topic: str,
                 producer_id: str,
                 resource_name: str,
                 resource_schema: t.Type[schema.Schema],
                 resource_data: t.Union[t.Dict, t.List, t.Tuple],
                 action: str,
                 phase: str,
                 timeout=5) -> None:
        self.resource_name = resource_name
        self.resource_schema = resource_schema
        self.resource_data = resource_data
        self.action = action
        self.phase = phase

        super().__init__(
            producer=producer,
            topic=topic,
            key=conveyer.MessageKey(
                event_type=conveyer.EventType(
                    resource=self.resource_name,
                    action=self.action,
                    phase=self.phase,
                ),
                producer_id=producer_id,
            ),
            value=conveyer.MessageValue(
                schema=conveyer.load_schema_from_dict(self.schema),
                value=self.resource_data,
            ),
            timeout=timeout,
        )

    @property
    def schema(self) -> t.List[t.Dict]:
        """Avro Schema used to encode the payload.

        Example::

            [{
                "type": "record",
                "namespace": "com.bcom",
                "name": "Sample",
                "fields" : [
                    {"id": "name", "type": "string"},
                    {"name": "name", "type": "string"}
                ]
            }]
        """
        return self.resource_schema.get_avro_schema()
