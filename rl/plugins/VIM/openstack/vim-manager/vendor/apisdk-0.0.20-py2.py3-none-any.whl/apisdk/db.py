# Copyright 2018 b<>com. All rights reserved.
# This software is the confidential intellectual property of b<>com. You shall
# not disclose it and shall use it only in accordance with the terms of the
# license agreement you entered into with b<>com.
# IDDN number:
#
# -*- coding: utf-8 -*-

import logging
import uuid

import arrow
import simplejson
import sqlalchemy
from sqlalchemy import Column
from sqlalchemy import DateTime
from sqlalchemy import exc as dbexc
from sqlalchemy.orm.query import Query
from sqlalchemy.orm.session import Session
from sqlalchemy import types

from apisdk import exception

LOG = logging.getLogger(__name__)


def generate_uuid(dashed=True):
    """Creates a random uuid string.

    :param dashed: Generate uuid with dashes or not
    :type dashed: bool
    :returns: string
    """
    if dashed:
        return str(uuid.uuid4())
    return uuid.uuid4().hex


def _format_uuid_string(string):
    return (string.replace('urn:', '')
                  .replace('uuid:', '')
                  .strip('{}')
                  .replace('-', '')
                  .lower())


def is_uuid_like(val):
    """Returns validation of a value as a UUID.

    :param val: Value to verify
    :type val: string
    :returns: bool

    .. versionchanged:: 1.1.1
       Support non-lowercase UUIDs.
    """
    try:
        return str(uuid.UUID(val)).replace('-', '') == _format_uuid_string(val)
    except (TypeError, ValueError, AttributeError):
        return False


class TimestampMixin:
    created_at = Column(DateTime, default=lambda: arrow.utcnow().datetime)
    updated_at = Column(DateTime, onupdate=lambda: arrow.utcnow().datetime)


class QueryMixin:

    def __setitem__(self, key, value):
        setattr(self, key, value)

    def __getitem__(self, key):
        return getattr(self, key)

    def __contains__(self, key):
        try:
            getattr(self, key)
        except AttributeError:
            return False
        else:
            return True

    @classmethod
    def get_session(cls) -> Session:
        raise NotImplementedError()

    @classmethod
    def get_query(cls, *args, **kwargs) -> Query:
        raise NotImplementedError()

    @classmethod
    def create(cls, **kwargs):
        """Create a new record and save it the database."""
        obj = cls(**kwargs)
        return obj.save()

    def update(self, commit=True, **kwargs):
        """Update specific fields of a record."""
        for attr, value in kwargs.items():
            setattr(self, attr, value)
        self.save()
        return self

    def save(self, commit=True):
        """Save the record."""
        session = self.get_session()
        session.add(self)
        if commit:
            try:
                session.commit()
                session.flush()
            except (dbexc.IntegrityError, sqlalchemy.orm.exc.FlushError):
                session.rollback()
                raise exception.ResourceAlreadyExists(
                    name=type(self).__name__, id=self.id)
            except dbexc.DatabaseError as exc:
                LOG.exception(exc)
                session.rollback()
                raise exception.DatabaseError(id=self.id, error=exc)
        return self

    def delete(self, commit=True):
        """Remove the record from the database."""
        session = self.get_session()
        session.delete(self)
        if commit:
            try:
                session.commit()
            except dbexc.DatabaseError as exc:
                LOG.exception(exc)
                session.rollback()
                raise exception.DatabaseError(id=self.id, error=exc)
        return self

    @classmethod
    def list(cls):
        return cls.get_query().all()

    @classmethod
    def get_by_id(cls, id):
        """Get record by ID."""
        try:
            return cls.get_query().filter(cls.id == id).one()
        except sqlalchemy.orm.exc.NoResultFound:
            raise exception.NotFound(
                "%(model)s '%(id)s' could not be found" % dict(
                    model=cls.__name__, id=id))

    @classmethod
    def get_or_create(cls, id, **kwargs):
        """Get or create object."""
        try:
            return cls.get_by_id(id)
        except exception.NotFound:
            return cls.create(id=id, **kwargs)

    def as_dict(self):
        data = {}
        for column in self.__table__.columns:
            data[column.name] = self[column.name]
        return data


class JsonEncodedType(types.TypeDecorator):
    """Abstract base type serialized as json-encoded string in db."""

    type = None  # type: Union[Dict, List]
    impl = types.Unicode

    def process_bind_param(self, value, dialect):
        if value is None:
            # Save default value according to current type to keep the
            # interface the consistent.
            value = self.type()
        elif not isinstance(value, self.type):
            raise TypeError("%s supposes to store %s objects, but %s given"
                            % (self.__class__.__name__,
                               self.type.__name__,
                               type(value).__name__))
        serialized_value = simplejson.dumps(value)
        return serialized_value

    def process_result_value(self, value, dialect):
        if value is not None:
            value = simplejson.loads(value)
        return value


class JsonDict(JsonEncodedType):
    """Represents dict serialized as json-encoded string in db."""

    type = dict


class JsonList(JsonEncodedType):
    """Represents list serialized as json-encoded string in db."""

    type = list
