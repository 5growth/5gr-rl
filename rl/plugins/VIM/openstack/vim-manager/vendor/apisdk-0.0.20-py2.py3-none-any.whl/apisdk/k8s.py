# -*- coding: utf-8 -*-

import logging
import typing as t

from apisdk import service
import kubernetes

LOG = logging.getLogger(__name__)


class KubernetesEventHandler(service.ThreadedService):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.watcher = kubernetes.watch.Watch()
        self._apiclient = None

    @property
    def apiclient(self) -> kubernetes.client.ApiClient:
        raise NotImplementedError()

    def get_watchable_signature(self) -> t.Dict:
        """Return a function signature that can be 'watched'

        This method should return a callable without any parameter that
        queries Kubernetes resources (e.g. list_node or list_namespaced_pod)
        Use functools.partial(func, *args, **keywords) if you need parameters)
        For example:
        >>> v1 = kubernetes.client.CoreV1Api()
        >>> return dict(
        ...     callable=v1.list_node,
        ...     args=(),
        ...     kwargs=dict(label_selector="node-type=edge,other!=bad"),
        ... )
        """
        raise NotImplementedError

    def on_added(self, event_type: str, obj: t.Any, raw_obj: dict) -> None:
        raise NotImplementedError

    def on_modified(self, event_type: str, obj: t.Any, raw_obj: dict) -> None:
        raise NotImplementedError

    def on_deleted(self, event_type: str, obj: t.Any, raw_obj: dict) -> None:
        raise NotImplementedError

    def on_error(self,
                 event_type: str,
                 obj: kubernetes.client.V1Status,
                 raw_obj: dict) -> None:
        raise NotImplementedError

    def dispatch(self, event_type: str, obj: t.Any, raw_obj: dict) -> None:
        if event_type == "ADDED":
            # For added objects, this is the new object
            self.on_added(
                event_type=event_type, obj=obj, raw_obj=raw_obj)
        elif event_type == "MODIFIED":
            # For modified objects, this is the updated object
            self.on_modified(
                event_type=event_type, obj=obj, raw_obj=raw_obj)
        elif event_type == "DELETED":
            # For deleted objects, it corresponds to the state of
            # the object immediately prior to its deletion.
            self.on_deleted(
                event_type=event_type, obj=obj, raw_obj=raw_obj)
        elif event_type == "ERROR":
            # For errors, this is an API `V1Status`
            self.on_error(
                event_type=event_type, obj=obj, raw_obj=raw_obj)
        else:
            LOG.warning("Unknown event type: %s", event_type)

    def run(self):
        # NOTE(vfrancoise): See https://github.com
        # /kubernetes/kubernetes/blob/master/pkg/watch/json/types.go#L35
        # The type of watch event; may be ADDED, MODIFIED, DELETED, or ERROR
        signature = self.get_watchable_signature()
        for event in self.watcher.stream(
                signature["callable"],
                *signature["args"],
                **signature["kwargs"]):
            event_type = event["type"]
            obj = event["object"]
            raw_obj = event["raw_object"]

            LOG.info("[NODE EVENT]: %s", event_type)
            LOG.debug("Event type=%s | raw object= %s", event_type, raw_obj)
            try:
                self.dispatch(event_type=event_type, obj=obj, raw_obj=raw_obj)
            except (KeyboardInterrupt, SystemExit):
                raise
            except Exception as exc:
                LOG.exception(exc)
