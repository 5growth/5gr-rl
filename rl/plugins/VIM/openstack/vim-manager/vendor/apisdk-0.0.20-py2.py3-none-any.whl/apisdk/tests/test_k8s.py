# Copyright 2018 b<>com. All rights reserved.
# This software is the confidential intellectual property of b<>com. You shall
# not disclose it and shall use it only in accordance with the terms of the
# license agreement you entered into with b<>com.
# IDDN number:
#
# -*- coding: utf-8 -*-

from unittest import mock

import logging
import typing as t

from apisdk import k8s
import kubernetes

LOG = logging.getLogger(__name__)


class FakeHandler(k8s.KubernetesEventHandler):

    watchable_signature = dict(
        callable=kubernetes.client.CoreV1Api().list_node,
        args=(),
        kwargs=dict(label_selector="is-fake=true"),
    )

    def apiclient(self) -> kubernetes.client.ApiClient:
        if self._apiclient is None:
            self._apiclient = kubernetes.client.ApiClient()

        return self._apiclient

    def get_watchable_signature(self) -> t.Dict:
        return self.watchable_signature

    def on_added(self, event_type: str, obj: t.Any, raw_obj: dict) -> None:
        self.kwargs["mock"](event_type, obj, raw_obj)

    def on_modified(self, event_type: str, obj: t.Any, raw_obj: dict) -> None:
        self.kwargs["mock"](event_type, obj, raw_obj)

    def on_deleted(self, event_type: str, obj: t.Any, raw_obj: dict) -> None:
        self.kwargs["mock"](event_type, obj, raw_obj)

    def on_error(self,
                 event_type: str,
                 obj: kubernetes.client.V1Status,
                 raw_obj: dict) -> None:
        self.kwargs["mock"](event_type, obj, raw_obj)


def test_run_kubernetes_handler(mocker):
    fake_added_event = dict(
        type="ADDED",
        object=mock.Mock(name="fake-object"),
        raw_object={},
    )
    fake_modified_event = dict(
        type="MODIFIED",
        object=mock.Mock(name="fake-object"),
        raw_object={},
    )
    fake_deleted_event = dict(
        type="DELETED",
        object=mock.Mock(name="fake-object"),
        raw_object={},
    )
    fake_error_event = dict(
        type="ERROR",
        object=mock.Mock(name="fake-object"),
        raw_object={},
    )
    m_stream = mocker.patch.object(kubernetes.watch.Watch, "stream")
    m_stream.return_value = [
        fake_added_event,
        fake_modified_event,
        fake_deleted_event,
        fake_error_event,
    ]

    mock_handler = mock.MagicMock(name="fake-handler")
    handler = FakeHandler(mock=mock_handler)

    handler.start()
    handler.stop()

    # Tuple such as (args, kwargs)
    assert mock_handler.call_args_list == [
        ((fake_added_event["type"], fake_added_event["object"], {}), {}),
        ((fake_modified_event["type"], fake_modified_event["object"], {}), {}),
        ((fake_deleted_event["type"], fake_deleted_event["object"], {}), {}),
        ((fake_error_event["type"], fake_error_event["object"], {}), {}),
    ]
