# -*- coding: utf-8 -*-

import time
from unittest import mock

from apisdk import service


class FakeThreadedService(service.ThreadedService):

    def __init__(self, app, **kwargs):
        super().__init__(**kwargs)
        self.app = app

    def run(self):
        self.app.run()

    def wait(self):
        pass


class FakeProcessService(service.ProcessService):

    def __init__(self, app, **kwargs):
        super().__init__(**kwargs)
        self.app = app

    def run(self):
        self.app.run()


def test_threaded_service(mocker):
    app = mock.MagicMock(name="fake-app")
    app.run.side_effect = lambda: time.sleep(1)
    svc = FakeThreadedService(app=app)

    svc.start()
    status = svc.get_health_status()
    svc.stop()

    app.run.call_count == 1
    assert status.as_dict() == dict(
        status="ok",
        reason=None,
    )


def test_threaded_service_error_status(mocker):
    app = mock.MagicMock(name="fake-app")
    svc = FakeThreadedService(app=app)
    svc.error_queue.put(Exception("test"))

    status = svc.get_health_status()

    app.run.call_count == 1
    assert status.as_dict() == dict(
        status="error",
        reason="test",
    )


def test_process_service_error_status(mocker):
    app = mock.MagicMock(name="fake-app")
    svc = FakeProcessService(app=app)
    svc.error_queue.put(Exception("test"))
    time.sleep(.01)  # The queue.put() is async so sleep() wait for bg sync

    status = svc.get_health_status()

    app.run.call_count == 1
    assert status.as_dict() == dict(
        status="error",
        reason="test",
    )


def test_start_process_service(mocker):
    app = mock.MagicMock(name="fake-app")
    app.run.side_effect = lambda: time.sleep(1)
    svc = FakeProcessService(app=app)

    svc.start()
    status = svc.get_health_status()
    svc.stop()

    app.run.call_count == 1
    assert status.as_dict() == dict(
        status="ok",
        reason=None,
    )


def test_service_manager(mocker):
    app = mock.MagicMock(name="fake-app")
    app.run.side_effect = lambda: time.sleep(1)
    manager = service.ServiceManager(services=[FakeThreadedService], app=app)

    manager.start()
    status = manager.get_health_status()
    manager.stop()

    app.run.call_count == 1
    assert status.as_dict() == dict(
        status="ok",
        reason=None,
    )
