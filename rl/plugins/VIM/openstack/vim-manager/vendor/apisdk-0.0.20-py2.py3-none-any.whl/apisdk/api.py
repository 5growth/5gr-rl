# -*- coding: utf-8 -*-

import datetime
import http
import logging
import uuid

import arrow
import conveyer
import flask
import simplejson

LOG = logging.getLogger(__name__)

healthz_blueprint = flask.Blueprint('healthz', __name__)


class CustomJSONEncoder(simplejson.JSONEncoder):

    def default(self, obj):
        if isinstance(obj, (datetime.datetime, arrow.Arrow)):
            return str(arrow.get(obj))
        if isinstance(obj, uuid.UUID):
            return str(obj)
        return super(CustomJSONEncoder, self).default(obj)


class FlaskApp(flask.Flask):
    """Kubernetes-compliant Flask App."""

    json_encoder = CustomJSONEncoder

    def healthz(self) -> conveyer.HealthStatus:
        raise NotImplementedError()

    def readyz(self) -> conveyer.HealthStatus:
        return self.healthz()


@healthz_blueprint.route("/healthz")
def healthz():
    """Healthcheck

    ---
    description: ""
    responses:
        200:
            description: Healthcheck
        503:
            description: Service Unavailable
    """
    status_code = http.HTTPStatus.OK.value

    health_status = flask.current_app.healthz()
    if health_status.reason:
        status_code = http.HTTPStatus.SERVICE_UNAVAILABLE.value

    LOG.debug(health_status.as_dict())

    return flask.jsonify(health_status.as_dict()), status_code


@healthz_blueprint.route("/readyz")
def readyz():
    """Readiness check

    ---
    description: ""
    responses:
        200:
            description: Readiness check
        503:
            description: Service Unavailable
    """
    status_code = http.HTTPStatus.OK.value

    health_status = flask.current_app.readyz()
    if health_status.reason:
        status_code = http.HTTPStatus.SERVICE_UNAVAILABLE.value

    LOG.debug(health_status.as_dict())

    return flask.jsonify(health_status.as_dict()), status_code
