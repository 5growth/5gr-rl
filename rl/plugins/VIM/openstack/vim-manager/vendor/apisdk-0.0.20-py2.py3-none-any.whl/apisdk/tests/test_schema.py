# Copyright 2018 b<>com. All rights reserved.
# This software is the confidential intellectual property of b<>com. You shall
# not disclose it and shall use it only in accordance with the terms of the
# license agreement you entered into with b<>com.
# IDDN number:
#
# -*- coding: utf-8 -*-

import enum

from apisdk import schema
from conveyer import load_schema_from_dict


class DoubleInner(schema.Schema):
    double_inner_list = schema.List(schema.Str, required=True)


class Inner(schema.Schema):
    double_inner = schema.Nested(DoubleInner, required=True)


class Outer(schema.Schema):
    name = schema.Str(required=True)
    inner = schema.Nested(Inner, required=True)


def test_convert_str():
    field = schema.Str(required=False)
    avro_records, avro_field = schema.convert_as_avro_field(
        name="test", field=field)

    expected_records = []
    expected_field = dict(name="test", type=["string", "null"])

    assert avro_records == expected_records
    assert avro_field == expected_field


def test_convert_raw():
    field = schema.Raw(required=False)
    avro_records, avro_field = schema.convert_as_avro_field(
        name="test", field=field)

    expected_records = []
    expected_field = dict(name="test", type=["string", "null"])

    assert avro_records == expected_records
    assert avro_field == expected_field


def test_convert_int():
    field = schema.Int(required=False)
    avro_records, avro_field = schema.convert_as_avro_field(
        name="test", field=field)

    expected_records = []
    expected_field = dict(name="test", type=["int", "null"])

    assert avro_records == expected_records
    assert avro_field == expected_field


def test_convert_datetime():
    field = schema.DateTime(required=False)
    avro_records, avro_field = schema.convert_as_avro_field(
        name="test", field=field)

    expected_records = []
    expected_field = dict(name="test", type=["string", "null"])

    assert avro_records == expected_records
    assert avro_field == expected_field


def test_convert_enum():
    class TestEnum(enum.Enum):
        first = "first"
        second = "second"
    field = schema.Enum(enum=TestEnum, required=False)
    avro_records, avro_field = schema.convert_as_avro_field(
        name="test", field=field)

    expected_records = []
    expected_field = dict(
        name="test",
        symbols=['first', 'second'],
        type=["enum", "null"],
    )

    assert avro_records == expected_records
    assert avro_field == expected_field


def test_convert_str_required():
    field = schema.Str(required=True)
    avro_records, avro_field = schema.convert_as_avro_field(
        name="test", field=field)

    expected_records = []
    expected_field = dict(name="test", type="string")

    assert avro_records == expected_records
    assert avro_field == expected_field


def test_convert_list():
    field = schema.List(schema.UUIDStr(required=True), required=False)
    avro_records, avro_field = schema.convert_as_avro_field(
        name="test", field=field)

    expected_records = []
    expected_field = dict(
        name="test", type=[dict(items="string", type="array"), "null"])

    assert avro_records == expected_records
    assert avro_field == expected_field


def test_convert_dict():
    field = schema.Dict(required=False)
    avro_records, avro_field = schema.convert_as_avro_field(
        name="test", field=field)

    expected_records = []
    expected_field = dict(
        name="test",
        type=[
            dict(
                type="map",
                values=[
                    "string",
                    "int",
                    "long",
                    dict(type="array",
                         items=["string", "int", "long", "null"]),
                    dict(type="map",
                         values=["string", "int", "long", "null"]),
                    "null"]
                ),
            "null"]
    )

    assert avro_records == expected_records
    assert avro_field == expected_field


def test_convert_nested_object():
    field = schema.Nested(Inner, required=False)
    avro_records, avro_field = schema.convert_as_avro_field(
        name="test", field=field)

    expected_records = [
        dict(
            fields=[{
                "name": "double_inner_list",
                "type": {"items": ["string", "null"], "type": "array"}}],
            name="DoubleInner",
            namespace="com.bcom",
            type="record",
        ), dict(
            fields=[{"name": "double_inner", "type": "DoubleInner"}],
            name="Inner",
            namespace="com.bcom",
            type="record",
        ),
    ]
    expected_field = dict(name="test", type=["Inner", "null"])

    assert avro_records == expected_records
    assert avro_field == expected_field


def test_convert_complex_schema():
    avro_schema = Outer.get_avro_schema()
    assert load_schema_from_dict(avro_schema)
