# Copyright 2018 b<>com. All rights reserved.
# This software is the confidential intellectual property of b<>com. You shall
# not disclose it and shall use it only in accordance with the terms of the
# license agreement you entered into with b<>com.
# IDDN number:
#
# -*- coding: utf-8 -*-

import enum
import operator
import typing as t
import uuid

from jsonschema import validators
import marshmallow
from marshmallow import fields
import marshmallow_enum

DateTime = fields.DateTime
Enum = marshmallow_enum.EnumField
Int = fields.Int
List = fields.List
Dict = fields.Dict
Raw = fields.Raw
Str = fields.String  # type: "t.Any"
Nested = fields.Nested  # type: "t.Any"


def extend_with_xnullable(validator_class):
    validate_properties = validator_class.VALIDATORS["properties"]

    def set_nullables(validator, properties, instance, schema):
        for prop, subschema in properties.items():
            if "x-nullable" in subschema:
                nullable_subschema = dict(anyOf=[subschema, dict(type="null")])
                schema["properties"][prop] = nullable_subschema

        for error in validate_properties(
            validator, properties, instance, schema
        ):
            yield error

    return validators.extend(validator_class, {"properties": set_nullables})


Draft4Validator = validators.Draft4Validator
XNullableDraft4Validator = extend_with_xnullable(Draft4Validator)


def validation_function(_, instance, schema, cls=None, *args, **kwargs):
    if not cls:
        cls = XNullableDraft4Validator
    return validators.validate(
        instance=instance, schema=schema, cls=cls, *args, **kwargs)


def convert_as_avro_records(schema: marshmallow.Schema) -> t.List[t.Dict]:
    avro_records = []
    avro_fields = []
    fieldmap = schema.declared_fields
    for fieldname, field in fieldmap.items():
        _records, _field = convert_as_avro_field(fieldname, field)
        avro_records.extend(_records)
        avro_fields.append(_field)

    avro_record = dict(
        namespace="com.bcom",
        type="record",
        name=schema.__class__.__name__,
        fields=avro_fields,
    )
    avro_records.append(avro_record)

    return avro_records


def convert_as_avro_field(name: str, field: fields.Field) -> t.Dict:
    avro_records = []
    avro_field = None
    null = "null"

    if isinstance(field, Str):
        field_type = "string"
        field_types = field_type if field.required else [field_type, null]
        avro_field = dict(name=name, type=field_types)
    elif isinstance(field, DateTime):
        field_type = "string"
        field_types = field_type if field.required else [field_type, null]
        avro_field = dict(name=name, type=field_types)
    elif isinstance(field, Enum):
        symbols = [item.value for item in field.enum]
        field_type = "enum"
        field_types = field_type if field.required else [field_type, null]
        avro_field = dict(name=name, type=field_types, symbols=symbols)
    elif isinstance(field, Int):
        field_type = "int"
        field_types = field_type if field.required else [field_type, null]
        avro_field = dict(name=name, type=field_types)
    elif isinstance(field, List):
        items_records, items_field = convert_as_avro_field(
            name="item", field=field.container)
        avro_records.extend(items_records)
        items_type = items_field["type"]
        field_type = dict(type="array", items=items_type)
        field_types = field_type if field.required else [field_type, null]
        avro_field = dict(name=name, type=field_types)
    elif isinstance(field, Raw):
        field_type = "string"
        field_types = field_type if field.required else [field_type, null]
        avro_field = dict(name=name, type=field_types)
    elif isinstance(field, Dict):
        # We only allow 1 level of type nesting: use Nested records otherwise
        nested_value_types = ["string", "int", "long", null]
        dict_type = dict(type="map", values=nested_value_types)
        array_type = dict(type="array", items=nested_value_types)
        value_types = ["string", "int", "long", array_type, dict_type, null]

        field_type = dict(type="map", values=value_types)
        field_types = field_type if field.required else [field_type, null]
        avro_field = dict(name=name, type=field_types)
    elif isinstance(field, Nested):
        nested = field.nested
        if isinstance(field.nested, type):
            nested = field.nested()

        avro_records.extend(convert_as_avro_records(nested))
        nested_cls = nested if isinstance(nested, type) else nested.__class__
        field_type = nested_cls.__name__
        field_types = field_type if field.required else [field_type, null]
        avro_field = dict(name=name, type=field_types)

    if not avro_field:
        raise NotImplementedError(
            "Field type '%s' not supported!" % avro_field)

    return avro_records, avro_field


class Schema(marshmallow.Schema):

    @classmethod
    def get_avro_schema(cls):
        return convert_as_avro_records(cls())


def _contains(val, lst):
    return operator.contains(lst, val)


def _not_contains(val, lst):
    operator.not_(_contains(lst, val))


class QueryOperator(enum.Enum):
    """Query operators."""

    eq = operator.eq
    gt = operator.gt
    ge = operator.ge
    lt = operator.lt
    le = operator.le
    ne = operator.ne
    in_ = _contains
    notin = _not_contains


class PatchOperator(enum.Enum):
    """Patch operators."""

    add = "add"
    remove = "remove"
    replace = "replace"
    move = "move"
    copy = "copy"
    test = "test"


class UUIDStr(Str):
    """A UUID string field."""

    default_error_messages = {
        "invalid_uuid": "Not a valid UUID.",
        "invalid_guid": "Not a valid UUID.",
    }

    def _validated(self, value):
        if value is None:
            return None
        if isinstance(value, uuid.UUID):
            return str(value)
        try:
            return value
        except (ValueError, AttributeError):
            self.fail("invalid_uuid")

    def _serialize(self, value, attr, obj):
        validated = str(self._validated(value)) if value is not None else None
        return super(UUIDStr, self)._serialize(validated, attr, obj)

    def _deserialize(self, value, attr, data):
        return self._validated(value)


class TimestampedSchema(object):
    created_at = DateTime(missing=None, allow_none=True)
    updated_at = DateTime(default=None, missing=None, allow_none=True)


class Error(marshmallow.Schema, TimestampedSchema):
    code = Int(required=True)
    message = Str()


class SearchFilter(marshmallow.Schema):
    op = Enum(QueryOperator, required=True)
    field = Str(required=True)
    value = Raw(required=True)


class JsonPatch(marshmallow.Schema):
    """RFC6902-compliant JSON Patch item."""

    op = Enum(QueryOperator, required=True)
    path = Str(required=True)
    value = Raw(required=True)
