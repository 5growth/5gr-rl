# Copyright 2018 b<>com. All rights reserved.
# This software is the confidential intellectual property of b<>com. You shall
# not disclose it and shall use it only in accordance with the terms of the
# license agreement you entered into with b<>com.
# IDDN number:
#
# -*- encoding: utf-8 -*-

import logging

import simplejson
from werkzeug import exceptions as wexc

LOG = logging.getLogger(__name__)


class ApiException(wexc.HTTPException):
    """Base Exception.

    To correctly use this class, inherit from it and define
    a 'description' property. That description will get printf'd
    with the keyword arguments provided to the constructor.
    """

    description = "An unknown exception occurred"
    code = 500

    def __init__(self, message=None, **kwargs):
        self.kwargs = kwargs

        if 'code' not in self.kwargs:
            try:
                self.kwargs['code'] = self.code
            except AttributeError:
                pass

        if not message:
            try:
                message = self.description % kwargs
            except Exception:
                # kwargs doesn't match a variable in description
                # log the issue and the kwargs
                LOG.exception('Exception in string format operation')
                for name, value in kwargs.items():
                    LOG.error("%(name)s: %(value)s",
                              {'name': name, 'value': value})

                # at least get the core description out if something happened
                message = self.description

        super().__init__(message)

    def __str__(self):
        """Encode to utf-8 then wsme api can consume it as well"""
        return self.description

    def format_message(self):
        if self.__class__.__name__.endswith('_Remote'):
            return self.args[0]
        return str(self)

    def get_headers(self, environ=None):
        """Get a list of headers."""
        return [('Content-Type', 'application/json')]

    def get_body(self, environ=None):
        """Get the error body."""
        return simplejson.dumps({
            'code': self.code,
            'name': self.name,
            'description': self.get_description(environ),
        })

    def get_description(self, environ=None):
        return u'%s' % self.description


class BadRequest(wexc.BadRequest, ApiException):
    """BadRequest"""


class Conflict(wexc.Conflict, ApiException):
    """Conflict"""


class NotFound(wexc.NotFound, ApiException):
    """Not Found"""


class ResourceNotFound(NotFound):
    description = "The %(name)s resource %(id)s could not be found"


class ResourceAlreadyExists(Conflict):
    description = "A %(name)s with ID %(id)s already exists"


class DatabaseError(wexc.InternalServerError):
    description = "A database operation failed on %(id)s : %(error)s"
