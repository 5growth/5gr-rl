# Copyright 2018 b<>com. All rights reserved.
# This software is the confidential intellectual property of b<>com. You shall
# not disclose it and shall use it only in accordance with the terms of the
# license agreement you entered into with b<>com.
# IDDN number:
#
# -*- coding: utf-8 -*-

import datetime

import freezegun
import pytest
from sqlalchemy import Column
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.inspection import inspect
from sqlalchemy.orm import scoped_session
from sqlalchemy.orm import sessionmaker
from sqlalchemy import String

from apisdk import db
from apisdk import exception

engine = create_engine("sqlite:///:memory:")
ModelBase = declarative_base(bind=engine)
session_factory = sessionmaker(bind=engine)
Session = scoped_session(session_factory)
session = Session()


class Model(db.QueryMixin, db.TimestampMixin, ModelBase):
    """Base Model."""

    __abstract__ = True

    id = Column(
        String(length=48),
        primary_key=True,
        default=lambda: db.generate_uuid())

    @classmethod
    def get_session(cls):
        return session

    @classmethod
    def get_query(cls, *args, **kwargs):
        session = cls.get_session()
        return session.query(cls, *args, **kwargs)


class FakeModel(Model):
    __tablename__ = 'fakes'

    name = Column(String(length=255))
    properties = Column(db.JsonDict(), default={})


@pytest.yield_fixture(scope='function')
def db_session():
    """A database for the tests."""
    ModelBase.metadata.create_all(engine)

    yield session

    for tbl in reversed(ModelBase.metadata.sorted_tables):
        session.bind.execute(tbl.delete())


@pytest.fixture
def unsaved_model(db_session):
    return FakeModel(name="test")


@pytest.fixture
def model(db_session):
    return FakeModel.create(
        id=db.generate_uuid(),
        name="test",
        properties={},
        created_at=datetime.datetime(2018, 10, 11, 0, 0))


@freezegun.freeze_time("2018-10-11")
def test_create(db_session):
    uuid = db.generate_uuid()
    model = FakeModel.create(id=uuid, name="test-create")

    assert model.as_dict() == dict(
        id=uuid,
        name="test-create",
        properties={},
        created_at=datetime.datetime(2018, 10, 11, 0, 0),
        updated_at=None,
    )


@freezegun.freeze_time("2018-10-11")
def test_create_already_exists(model):
    with pytest.raises(exception.ResourceAlreadyExists):
        FakeModel.create(id=model.id, name="test-create")


@freezegun.freeze_time("2018-10-11")
def test_update(model):
    model.update(name="updated")

    assert model.as_dict() == dict(
        id=model.id,
        name="updated",
        properties={},
        created_at=datetime.datetime(2018, 10, 11, 0, 0),
        updated_at=datetime.datetime(2018, 10, 11, 0, 0),
    )


@freezegun.freeze_time("2018-10-11")
def test_save(db_session):
    uuid = db.generate_uuid()
    model = FakeModel(id=uuid, name="test-save")
    model.save()

    assert model.as_dict() == dict(
        id=uuid,
        name="test-save",
        properties={},
        created_at=datetime.datetime(2018, 10, 11, 0, 0),
        updated_at=None
    )


@freezegun.freeze_time("2018-10-11")
def test_delete(model):
    model.delete()

    assert model.as_dict() == dict(
        id=model.id,
        name="test",
        properties={},
        created_at=datetime.datetime(2018, 10, 11, 0, 0),
        updated_at=None
    )
    assert inspect(model).detached


@freezegun.freeze_time("2018-10-11")
def test_list(model):
    models = FakeModel.list()
    assert [mm.as_dict() for mm in models] == [dict(
        id=model.id,
        name="test",
        properties={},
        created_at=datetime.datetime(2018, 10, 11, 0, 0),
        updated_at=None
    )]


@freezegun.freeze_time("2018-10-11")
def test_get_by_id(model):
    result = model.get_by_id(id=model.id)

    assert result.as_dict() == model.as_dict()


@freezegun.freeze_time("2018-10-11")
def test_get_by_id_not_found(model):
    with pytest.raises(exception.NotFound):
        model.get_by_id(id=db.generate_uuid())


@freezegun.freeze_time("2018-10-11")
def test_get_or_create_already_exists(model):
    result = model.get_or_create(id=model.id)
    assert result.as_dict() == dict(
        id=model.id,
        name="test",
        properties={},
        created_at=datetime.datetime(2018, 10, 11, 0, 0),
        updated_at=None
    )


@freezegun.freeze_time("2018-10-11")
def test_get_or_create_does_not_exist(model):
    uuid = db.generate_uuid()
    result = model.get_or_create(id=uuid, name="new")
    assert result.as_dict() == dict(
        id=uuid,
        name="new",
        properties={},
        created_at=datetime.datetime(2018, 10, 11, 0, 0),
        updated_at=None
    )


@freezegun.freeze_time("2018-10-11")
def test_model_dict_like(model):
    model["name"] = "dict-like"
    assert model.as_dict() == dict(
        id=model.id,
        name="dict-like",
        properties={},
        created_at=datetime.datetime(2018, 10, 11, 0, 0),
        updated_at=None
    )
    assert "name" in model
    assert "test" not in model
