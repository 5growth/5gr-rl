# Copyright 2018 b<>com. All rights reserved.
# This software is the confidential intellectual property of b<>com. You shall
# not disclose it and shall use it only in accordance with the terms of the
# license agreement you entered into with b<>com.
# IDDN number:
#
# -*- coding: utf-8 -*-

import conveyer
import flasgger
from marshmallow import fields
import marshmallow_enum
import pbr.version

from apisdk import api
from apisdk import db
from apisdk import job
from apisdk import k8s
from apisdk import messaging
from apisdk import schema
from apisdk import service

__version__ = pbr.version.VersionInfo('apisdk').version_string()

TimestampMixin = db.TimestampMixin
QueryMixin = db.QueryMixin
JsonDict = db.JsonDict
JsonList = db.JsonList

ResourceNotification = messaging.ResourceNotification
SwaggerView = flasgger.SwaggerView
# Add support for x-nullable extension from Swagger specs into jsonschema
SwaggerView.validation_function = schema.validation_function

DateTime = fields.DateTime
Dict = fields.Dict
Enum = marshmallow_enum.EnumField
Int = fields.Int
List = fields.List
Nested = fields.Nested
Raw = fields.Raw
Str = fields.Str
Url = fields.URL

Schema = schema.Schema
QueryOperator = schema.QueryOperator
PatchOperator = schema.PatchOperator
UUIDStr = schema.UUIDStr
TimestampedSchema = schema.TimestampedSchema
Error = schema.Error
SearchFilter = schema.SearchFilter
JsonPatch = schema.JsonPatch


Service = service.Service
ThreadedService = service.ThreadedService
ProcessService = service.ProcessService
ServiceManager = service.ServiceManager
HealthStatus = conveyer.HealthStatus

AsyncJob = job.AsyncJob

FlaskApp = api.FlaskApp
healthz_blueprint = api.healthz_blueprint

KubernetesEventHandler = k8s.KubernetesEventHandler
