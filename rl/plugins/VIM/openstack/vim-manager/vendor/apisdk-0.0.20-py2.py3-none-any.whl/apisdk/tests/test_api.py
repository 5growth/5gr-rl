# -*- coding: utf-8 -*-

from unittest import mock

import apisdk
import conveyer
import pytest
import webtest

from apisdk import api


class FakeApplication(api.FlaskApp):

    def healthz(self):
        return conveyer.HealthStatus(status=conveyer.HealthStatus.OK)


@pytest.yield_fixture(scope='function')
def app():
    """An application for the tests."""
    _app = FakeApplication("fake-application")
    _app.register_blueprint(api.healthz_blueprint)
    ctx = _app.test_request_context()
    ctx.push()

    yield _app

    ctx.pop()


@pytest.fixture(scope='function')
def testapp(app):
    """A Webtest app."""
    return webtest.TestApp(app, extra_environ=None)


def test_healthz_blueprint(testapp, mocker):
    m_service_manager = mock.Mock(name="fake-service-manager")
    m_service_manager.get_health_status.return_value = apisdk.HealthStatus(
        status=apisdk.HealthStatus.OK,
    )
    response = testapp.get('/healthz')
    assert response.status_code == 200
