========
Overview
========

Toolkit shared among all microservices to factorize common code patterns.

* License: Not open source
* Documentation: https://forge.b-com.com/www/falcon/lib/
* Source: ssh://gitolite@forge.b-com.com/falcon/lib/apisdk.git/
* Sonar Quality Code: https://metric.b-com.com/dashboard?id=falcon.app%3Aapisdk

Architecture
------------

TODO

Features
--------

* TODO



