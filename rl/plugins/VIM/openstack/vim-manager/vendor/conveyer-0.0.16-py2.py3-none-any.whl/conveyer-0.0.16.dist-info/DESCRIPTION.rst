========
Overview
========

Messaging library using Kafka as a Message Queue

Please fill here a long description which must be at least 3 lines wrapped on
80 cols, so that distribution package maintainers can use it in their packages.
Note that this is a hard requirement.

* License: Not open source
* Documentation: https://forge.b-com.com/www/falcon/lib/
* Source: ssh://gitolite@forge.b-com.com/falcon/lib/conveyer.git/

Architecture
------------

TODO

Features
--------

* TODO



