# -*- coding: utf-8 -*-

import os
from unittest import mock

from kafka.consumer import fetcher as kfetching
import pytest
import simplejson

import conveyer
from conveyer import codec
from conveyer import simpleavro


@pytest.fixture(scope="session")
def key_codec():
    return codec.MessageKeyCodec()


@pytest.fixture(scope="session")
def schema1():
    schema_path = os.path.join(os.path.dirname(__file__), "dummy.avsc")
    with open(schema_path, "rb") as dummy_schema:
        return simplejson.load(dummy_schema)


@pytest.fixture(scope="session")
def value_codec(schema1):
    return codec.MessageValueCodec(simpleavro.load_schema_from_dict(schema1))


@pytest.fixture(scope="session")
def key1():
    return dict(
        id="10043d49-5c1d-4dd8-9986-33688ce50e74",
        event_type="topic1.test",
        producer_id="test_producer",
        timestamp="2018-03-05T09:54:57.647685+00:00",
    )


@pytest.fixture
def key2(mocker):
    return dict(
        id="10043d49-5c1d-4dd8-9986-33688ce50e74",
        event_type="topic2.test",
        producer_id="test_producer",
        timestamp="2018-03-05T09:54:57.647685+00:00",
    )


@pytest.fixture(scope="session")
def encoded_key1(key_codec, key1):
    return key_codec.dumps(key1)


@pytest.fixture
def encoded_key2(key_codec, key2):
    return key_codec.dumps(key2)


@pytest.fixture(scope="session")
def value1():
    return {"name": "Alyssa"}


@pytest.fixture(scope="session")
def encoded_value1(value_codec, value1):
    return value_codec.dumps(value1)


@pytest.fixture(scope="session")
def topic1():
    return "topic1"


@pytest.fixture(scope="session")
def topic2():
    return "topic2"


@pytest.fixture
def messages():
    return []


@pytest.fixture
def record1(schema1, topic1, key1, value1, messages):
    msg = kfetching.ConsumerRecord(
        topic=topic1,
        partition=0,
        offset=0,
        timestamp=0,
        timestamp_type=0,
        key=[key1],
        value=[value1],
        checksum=0,
        serialized_key_size=len(key1),
        serialized_value_size=len(value1),
    )
    messages.append(msg)
    return msg


@pytest.fixture
def msg1(record1):
    return conveyer.IncomingMessage.from_kafka_record(record1)


@pytest.fixture
def record2(schema1, topic2, key2, value1, messages):
    msg = kfetching.ConsumerRecord(
        topic=topic2,
        partition=0,
        offset=0,
        timestamp=0,
        timestamp_type=0,
        key=[key2],
        value=[value1],
        checksum=0,
        serialized_key_size=len(key2),
        serialized_value_size=len(value1),
    )
    messages.append(msg)
    return msg


@pytest.fixture
def msg2(record2):
    return conveyer.IncomingMessage.from_kafka_record(record2)


@pytest.fixture
def consumer1(mocker, topic1, messages):
    consumer = conveyer.MessageConsumer(
        topics=["test"],
        endpoints=["test-endpoint:30092"],
        group_id="test-group-id",
        client_id="test-client-id",
        handlers=(),
    )
    consumer._consumer = mock.MagicMock(
        name="kafka_consumer",
        __iter__=mock.Mock(return_value=iter(messages)))
    return consumer
