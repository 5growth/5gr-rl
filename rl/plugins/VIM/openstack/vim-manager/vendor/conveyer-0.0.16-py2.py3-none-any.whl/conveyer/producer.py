# -*- coding: utf-8 -*-

import kafka

from conveyer import codec


class MessageProducer:

    def __init__(self, endpoints, **kwargs):
        self.endpoints = endpoints
        self._kwargs = kwargs

        self._key_codec = codec.MessageKeyCodec()

        self._producer = None

    @property
    def producer(self):
        if self._producer is None:
            self._producer = kafka.KafkaProducer(
                bootstrap_servers=self.endpoints,
                key_serializer=self._key_codec.dumps,
                **self._kwargs
            )
        return self._producer

    def send(self, topic, key, value, timeout=5):
        future = self.producer.send(
            topic=topic, key=key, value=value)
        return future.get(timeout=timeout)

    def async_send(self, topic, key, value):
        return self.producer.send(topic=topic, key=key, value=value)
