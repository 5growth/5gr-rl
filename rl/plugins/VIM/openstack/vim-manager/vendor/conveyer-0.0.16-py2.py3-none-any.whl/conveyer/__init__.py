# -*- coding: utf-8 -*-

import pbr.version

from conveyer import codec
from conveyer import consumer
from conveyer import filtering
from conveyer import handling
from conveyer import message
from conveyer import producer
from conveyer import simpleavro


MessageKeyCodec = codec.MessageKeyCodec
MessageValueCodec = codec.MessageValueCodec

MessageConsumer = consumer.MessageConsumer
HealthStatus = consumer.HealthStatus

MessageProducer = producer.MessageProducer

EventType = message.EventType
MessageKey = message.MessageKey
MessageValue = message.MessageValue
IncomingMessage = message.IncomingMessage
OutgoingMessage = message.OutgoingMessage

MessageFilter = filtering.MessageFilter

MessageHandler = handling.MessageHandler

Avro = simpleavro.Avro
load_schema_from_file = simpleavro.load_schema_from_file
load_schema_from_dict = simpleavro.load_schema_from_dict
load_schema_from_string = simpleavro.load_schema_from_string

__version__ = pbr.version.VersionInfo('conveyer').version_string()
