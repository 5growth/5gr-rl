# -*- encoding: utf-8 -*-

import logging

LOG = logging.getLogger(__name__)


class LibException(Exception):
    """Base Exception.

    To correctly use this class, inherit from it and define
    a 'description' property. That description will get printf'd
    with the keyword arguments provided to the constructor.
    """

    description = "An unknown exception occurred"

    def __init__(self, message=None, **kwargs):
        self.kwargs = kwargs

        if not message:
            try:
                message = self.description % kwargs
            except Exception:
                # kwargs doesn't match a variable in description
                # log the issue and the kwargs
                LOG.exception('Exception in string format operation')
                for name, value in kwargs.items():
                    LOG.error("%(name)s: %(value)s",
                              {'name': name, 'value': value})

                # at least get the core description out if something happened
                message = self.description

        super().__init__(message)

    def __str__(self):
        return self.description

    def format_message(self):
        if self.__class__.__name__.endswith('_Remote'):
            return self.args[0]
        return str(self)


class MessageValueNotValid(LibException):
    """Message value not valid."""

    description = ("Message '%(value)s' does not comply with the "
                   "provided schema '%(schema)s'.")
