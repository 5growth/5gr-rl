# -*- coding: utf-8 -*-

import io
import typing

import avro.datafile
import avro.io
import avro.schema
import simplejson

Schema = avro.schema.Schema  # type: typing.Any


def load_schema_from_file(filepath: str) -> Schema:
    with open(filepath, "rb") as schema_file:
        raw_schema = schema_file.read()
    return load_schema_from_string(raw_schema)


def load_schema_from_string(raw_schema) -> Schema:
    schema_str = raw_schema
    if isinstance(raw_schema, bytes):
        schema_str = schema_str.decode("utf-8")
    return avro.schema.Parse(schema_str)


def load_schema_from_dict(schema: typing.Dict) -> Schema:
    return load_schema_from_string(simplejson.dumps(schema))


class Avro:
    """Codec used to encoded and/or decode a payload.

    There are 2 ways in which it can be used:

    * If instantiated without any schema, it can only be used to load
      self-contained payloads. Self-contained payloads include their
      schema alongside their payload which means we can "auto-detect" the data
      structure without being provided any information beforehand (see the
      avro 'object container'). In this case, one cannot use this to also
      encode a message value since it's schemaless.
    * If instantiated with a schema, it can be used to encode any payload using
      the provided schema. It can also be used to load self-contained payloads.
    """

    def __init__(self, schema: Schema=None) -> None:
        self.schema = schema

    def loads(self, data):
        bytes_buffer = io.BytesIO(data)
        reader = avro.datafile.DataFileReader(
            bytes_buffer, avro.io.DatumReader())
        return [el for el in reader]

    def dumps(self, data):
        bytes_buffer = io.BytesIO()
        writer = avro.datafile.DataFileWriter(
            bytes_buffer, avro.io.DatumWriter(), self.schema)

        # We detect if it's a single record or a list of elements
        if isinstance(data, (list, tuple)):
            for element in data:
                writer.append(element)
        else:
            writer.append(data)

        # Writes in the bytes buffer
        writer.flush()
        return bytes_buffer.getvalue()
