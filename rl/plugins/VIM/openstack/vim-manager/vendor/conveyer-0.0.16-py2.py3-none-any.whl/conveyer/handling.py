# -*- coding: utf-8 -*-

import logging

from conveyer import filtering


LOG = logging.getLogger(__name__)


class MessageHandler:

    def __init__(self, message, **params):
        """Instantiated just before starting the thread."""
        super().__init__()
        LOG.info("[EVENT] Handling event '%s'", message.event_type)
        self.message = message
        self.params = params

    @classmethod
    def get_filter_rule(cls, **params) -> filtering.MessageFilter:
        """A message is handled only if it matches these filtering rules."""
        raise NotImplementedError()

    def pre_execute(self) -> None:
        """Pre-process the incoming message."""
        pass

    def execute(self) -> None:
        """Handle the business logic processing of the message."""
        raise NotImplementedError()

    def post_execute(self) -> None:
        """Post-processing: practical for cleanup tasks made in pre_execute."""
        pass

    def handle_error(self, error: Exception) -> None:
        """Handle any error that occured while treating an incoming message."""
        raise

    def run(self) -> None:
        """Full execution workflow that is expected to run in a thread."""
        try:
            self.pre_execute()
            self.execute()
            self.post_execute()
        except Exception as exc:
            LOG.exception(exc)
            LOG.error(
                "An error occured while trying to handle "
                "%(msg)s by %(handler)s" % dict(
                    msg=self.message,
                    handler=self.__class__.__name__))
            self.handle_error(exc)
