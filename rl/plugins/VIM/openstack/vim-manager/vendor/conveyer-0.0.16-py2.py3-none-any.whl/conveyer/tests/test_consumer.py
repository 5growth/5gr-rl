# -*- coding: utf-8 -*-

from unittest import mock

import kafka
import pytest

from conveyer import codec
from conveyer import consumer as msgconsumer
from conveyer import filtering
from conveyer import handling
from conveyer import message as msg


class FakeException(Exception):
    pass


class DummyHandler(handling.MessageHandler):

    @classmethod
    def get_filter_rule(cls, **params):
        return filtering.MessageFilter(
            producer_id="test",
            event_type=r"topic1\.test",
        )

    def execute(self):
        pass


class DummyHandler2(handling.MessageHandler):

    @classmethod
    def get_filter_rule(cls, **params):
        return filtering.MessageFilter(
            producer_id="test",
            event_type=r"topic2\.test",
        )

    def execute(self):
        pass


class ShouldRaiseHandler(handling.MessageHandler):

    @classmethod
    def get_filter_rule(cls, **params):
        return filtering.MessageFilter(
            producer_id="test",
            event_type=r"topic1\.test",
        )

    def execute(self):
        raise FakeException()


def test_dispatch_message(mocker, consumer1, msg1):
    m_execute = mocker.patch.object(DummyHandler, "execute")

    consumer1._message_handlers = [DummyHandler, DummyHandler2]
    consumer1.dispatch(msg1)

    assert m_execute.call_count == 1


def test_handler_error_on_execute(consumer1, msg1):
    with pytest.raises(FakeException):
        future = consumer1.process(ShouldRaiseHandler, msg1)
        future.result()


def test_setup_kafka_consumer(mocker):
    m_kafka_consumer_cls = mocker.patch.object(kafka, "KafkaConsumer")
    m_key_codec_cls = mocker.patch.object(codec, "MessageKeyCodec")
    m_value_codec_cls = mocker.patch.object(codec, "MessageValueCodec")
    m_key_loads = mock.Mock(loads=mock.Mock(name="key_loads"))
    m_value_loads = mock.Mock(loads=mock.Mock(name="value_loads"))
    m_key_codec = mock.Mock(name="key_codec_mock", loads=m_key_loads)
    m_key_codec_cls.return_value = m_key_codec
    m_value_codec_cls.return_value = mock.Mock(loads=m_value_loads)

    consumer = msgconsumer.MessageConsumer(
        topics=["test"],
        endpoints=["test-endpoint:30092"],
        group_id="test-group-id",
        client_id="test-client-id",
        handlers=(),
    ).consumer

    m_kafka_consumer_cls.assert_called_once_with(
        "test",
        bootstrap_servers=["test-endpoint:30092"],
        group_id="test-group-id",
        client_id="test-client-id",
        key_deserializer=m_key_loads,
        value_deserializer=m_value_loads,
    )

    assert consumer is not None


def test_receive_message(mocker, consumer1, record1):
    consumer1.stop_event.set()
    m_dispatch = mocker.patch.object(msgconsumer.MessageConsumer, "dispatch")
    m_from_record = mocker.patch.object(
        msg.IncomingMessage, "from_kafka_record")
    fake_msg = mock.Mock(name="fake_msg")
    m_from_record.return_value = fake_msg

    consumer1.run()

    m_dispatch.assert_called_once_with(fake_msg)


def test_consumer_is_status_ok(mocker, consumer1, record1):
    m_is_alive = mocker.patch.object(msgconsumer.MessageConsumer, "is_alive")
    m_is_alive.return_value = True
    status = consumer1.get_health_status()

    m_is_alive.assert_called_once_with()
    assert status.as_dict() == dict(
        status="ok",
        reason=None,
    )


def test_consumer_is_status_error(mocker, consumer1, record1):
    m_is_alive = mocker.patch.object(msgconsumer.MessageConsumer, "is_alive")
    m_is_alive.return_value = False
    consumer1.queue.put(Exception("MOCKED"))

    status = consumer1.get_health_status()

    m_is_alive.assert_called_once_with()
    assert status.as_dict() == dict(
        status="error",
        reason="MOCKED",
    )
