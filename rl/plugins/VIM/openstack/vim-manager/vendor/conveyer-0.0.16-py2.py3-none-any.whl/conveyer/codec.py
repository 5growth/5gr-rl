# -*- coding: utf-8 -*-

import os

from conveyer import simpleavro


class MessageKeyCodec(simpleavro.Avro):

    def __init__(self):
        schema = simpleavro.load_schema_from_file(
            os.path.join(os.path.dirname(__file__), "key.avsc"))
        super().__init__(schema)


class MessageValueCodec(simpleavro.Avro):
    """Codec used to encoded and/or decode the value of a message.

    There are 2 ways in which it can be used:

    * If instantiated without any schema, it can only be used to load
      self-contained message values. Self-contained payloads include their
      schema alongside their payload which means we can "auto-detect" the data
      structure without being provided any information beforehand (see the
      avro 'object container'). In this case, one cannot use this to also
      encode a message value since it's schemaless.
    * If instantiated with a schema, it can be used to encode any payload using
      the provided schema. It can also be used to load self-contained payloads.
    """
