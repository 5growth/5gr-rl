# -*- coding: utf-8 -*-

from unittest import mock

import freezegun
import kafka
import pytest

from conveyer import codec
from conveyer import exception
from conveyer import message as conveyermsg
from conveyer import producer as prod
from conveyer import simpleavro


@freezegun.freeze_time("2018-03-09")
def test_convey_message(mocker):
    m_value_dumps = mocker.patch.object(codec.MessageValueCodec, "dumps")
    m_value_dumps.side_effect = lambda x: x

    fake_key = conveyermsg.MessageKey(
        event_type=conveyermsg.EventType(
            resource="test", action="fake", phase=None),
        producer_id="test_service",
    )
    fake_value = conveyermsg.MessageValue(
        schema=simpleavro.load_schema_from_dict(dict(
            namespace="com.bcom",
            type="record",
            name="FakeMessage",
            fields=[])),
        value=[],
    )
    fake_message = conveyermsg.OutgoingMessage(
        producer=mock.Mock(spec=prod.MessageProducer),
        topic="test_topic",
        key=fake_key,
        value=fake_value,
        timeout=1,
    )
    fake_message.convey()

    fake_message.producer.send.assert_called_once_with(
        topic='test_topic',
        key=fake_key.marshal(),
        value=fake_value.marshal(),
        timeout=1,
    )


@freezegun.freeze_time("2018-03-09")
def test_convey_invalid_message():
    fake_key = conveyermsg.MessageKey(
        event_type=conveyermsg.EventType(
            resource="test", action="fake", phase=None),
        producer_id="test_service",
    )
    fake_value = conveyermsg.MessageValue(
        schema=simpleavro.load_schema_from_dict(dict(
            namespace="com.bcom",
            type="record",
            name="FakeMessage",
            fields=[{"name": "test", "type": "int"}])),
        value=[{"test": "int_expected"}],
    )
    fake_message = conveyermsg.OutgoingMessage(
        producer=mock.Mock(spec=prod.MessageProducer),
        topic="test_topic",
        key=fake_key,
        value=fake_value,
        timeout=1,
    )

    with pytest.raises(exception.MessageValueNotValid):
        fake_message.convey()


def test_setup_message_producer(mocker):
    m_kafka_producer_cls = mocker.patch.object(kafka, "KafkaProducer")
    m_key_codec_cls = mocker.patch.object(codec, "MessageKeyCodec")
    m_key_dumps = mock.Mock(dumps=mock.Mock(name="key_dumps"))
    m_key_codec_cls.return_value = mock.Mock(dumps=m_key_dumps)

    producer = prod.MessageProducer(
        endpoints=["test-endpoint:30092"],
        client_id="test-client-id").producer

    m_kafka_producer_cls.assert_called_once_with(
        bootstrap_servers=["test-endpoint:30092"],
        client_id="test-client-id",
        key_serializer=m_key_dumps,
    )

    assert producer is not None
