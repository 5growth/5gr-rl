# -*- coding: utf-8 -*-

from concurrent import futures
import logging
import queue
import threading
import typing
import uuid

import kafka

from conveyer import codec
from conveyer import handling
from conveyer import message as conveyermsg

LOG = logging.getLogger(__name__)


class HealthStatus:

    OK = "ok"
    ERROR = "error"

    allowed_statuses = (OK, ERROR)

    def __init__(self, status: str, reason: str=None) -> None:
        self.status = status
        self.reason = reason

        if self.status not in self.allowed_statuses:
            raise ValueError("Status '%s' is not allowed." % self.status)

    def as_dict(self):
        return dict(status=self.status, reason=self.reason)


class MessageConsumer(threading.Thread):
    """Consumer IO loop for the Kafka consumer.

    NOTE(vfrancoise): Switch the inheritance to `multiprocessing.Process`
    whenever we feel there is some loss.
    """

    def __init__(
            self,
            topics: str,
            endpoints: typing.List[str],
            group_id: typing.Optional[str],
            handlers: typing.Iterable[handling.MessageHandler],
            client_id: typing.Optional[str]=None,
            handler_params: typing.Optional[typing.Dict]=None,
            **kwargs) -> None:
        super().__init__()
        self.topics = topics
        self.endpoints = endpoints
        self.group_id = group_id or str(uuid.uuid4())
        self.client_id = client_id or None
        # NOTE(vfrancoise): Use multiprocessing.Queue if using a
        # multiprocessing-based strategy instead of a threading-based one.
        self.queue = queue.Queue()

        self.daemon = True
        self._key_codec = codec.MessageKeyCodec()
        self._value_codec = codec.MessageValueCodec()

        self._kwargs = kwargs
        self._consumer = None

        self._message_handlers = handlers
        self._handler_params = handler_params or dict()

        self.worker_pool = futures.ThreadPoolExecutor()
        self.stop_event = threading.Event()

    @property
    def consumer(self):
        if self._consumer is None:
            self._consumer = kafka.KafkaConsumer(
                *self.topics,
                bootstrap_servers=self.endpoints,
                group_id=self.group_id,
                client_id=self.client_id,
                key_deserializer=self._key_codec.loads,
                value_deserializer=self._value_codec.loads,
                **self._kwargs
            )

        return self._consumer

    @property
    def message_handlers(self):
        """Provide the message handlers that can process incoming messages.

        :returns: A list of message handlers
        :rtype: :py:`~.MessageHandler`
        """
        return self._message_handlers

    def get_health_status(self):
        status = HealthStatus(status="ok")

        if not self.is_alive():
            consumer_error = "unknown"
            try:
                consumer_error = self.queue.get(timeout=0)
                # Requeue the exception for the next healthcheck
                self.queue.put(consumer_error)
            except Exception:
                pass
            status.status = "error"
            status.reason = str(consumer_error)

        return status

    def process(self, handler_cls, message) -> futures.Future:
        # The actual processing runs in a separate thread
        # so it doesn't block the IO loop
        # TODO(vfrancoise): Make it a Future/Promise so we can detect
        # that a threaded task failed
        return self.worker_pool.submit(
            handler_cls(message, **self._handler_params).run)

    def dispatch(self, msg):
        for handler_cls in self.message_handlers:
            if handler_cls.get_filter_rule(**self._handler_params).match(
                    producer_id=msg.producer_id,
                    event_type=msg.event_type,
                    meta=msg.key.get("meta", None),
                    payload=msg.value):
                # NOTE(vfrancoise): Maybe we can do something about the futures
                # here instead of simply ignoring it altogether
                self.process(handler_cls, msg)

    def run(self):
        try:
            while True:
                for record in self.consumer:
                    message = conveyermsg.IncomingMessage.from_kafka_record(
                        record)
                    self.dispatch(message)
                if self.stop_event.is_set():
                    break
        except Exception as exc:
            LOG.exception(exc)
            # We use a shared queue to make the exception bubble up to the
            # main thread.
            self.queue.put(exc)

        self.consumer.close()

    def wait(self):
        """Wait forever that the main loop ends."""
        self.join()

    def stop(self):
        self.stop_event.set()
