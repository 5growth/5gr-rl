# -*- coding: utf-8 -*-

import logging
import typing
import uuid

import arrow
from kafka.consumer import fetcher as kfetching

from conveyer import codec
from conveyer import exception
from conveyer import producer as mproducer
from conveyer import simpleavro

LOG = logging.getLogger(__name__)


class EventType:

    def __init__(self, resource: str, action: str, phase: str) -> None:
        self.resource = resource
        self.action = action
        self.phase = phase

    def __repr__(self):
        return "EventType(%s)" % str(self)

    def __str__(self):
        """Return a formatted event type with a standard structure."""
        elements = [self.resource, self.action, self.phase]
        return ".".join(el for el in elements if el)


class MessageKey:

    def __init__(self,
                 event_type: EventType,
                 producer_id: str,
                 id: typing.Optional[str]=None,
                 timestamp: typing.Optional[str]=None,
                 ) -> None:
        self.id = id or str(uuid.uuid4())
        self.event_type = event_type
        self.producer_id = producer_id
        self._timestamp = timestamp

    @property
    def timestamp(self):
        if self._timestamp is None:
            return str(arrow.utcnow())
        return self._timestamp

    def marshal(self):
        return dict(
            id=self.id,
            event_type=str(self.event_type),
            producer_id=self.producer_id,
            timestamp=self.timestamp,
        )


class MessageValue:

    def __init__(self,
                 schema: simpleavro.Schema,
                 value: typing.Union[list, tuple, dict]) -> None:
        self.schema = schema
        self.value = value

    def marshal(self):
        # We check that the provided value is dumpable before sending it.
        try:
            codec.MessageValueCodec(self.schema).dumps(self.value)
        except Exception as exc:
            LOG.exception(exc)
            raise exception.MessageValueNotValid(
                value=self.value, schema=self.schema.to_json())
        return self.value


class IncomingMessage:

    def __init__(self,
                 topic: str,
                 key: typing.Dict,
                 value: typing.Union[typing.Dict, typing.List],
                 ) -> None:
        self.topic = topic
        self.key = key
        self.value = value

    @property
    def id(self):
        return self.key['id']

    @property
    def event_type(self):
        return self.key['event_type']

    @property
    def producer_id(self):
        return self.key['producer_id']

    @property
    def timestamp(self):
        return self.key['timestamp']

    @classmethod
    def from_kafka_record(cls, record: kfetching.ConsumerRecord):
        key = record.key if not isinstance(record.key, list) else record.key[0]
        if not len(record.value) or len(record.value) != 1:
            value = record.value
        else:
            value = record.value[0]

        return cls(
            topic=record.topic,
            key=key,
            value=value,
        )


class OutgoingMessage:

    def __init__(self,
                 producer: mproducer.MessageProducer,
                 topic: str,
                 key: MessageKey,
                 value: MessageValue,
                 timeout: int) -> None:
        self.topic = topic
        self.key = key
        self.value = value
        self.producer = producer
        self.timeout = timeout

    def convey(self):
        LOG.info("=> Conveying message: topic=%s, event=%s",
                 self.topic, self.key.event_type)
        LOG.debug("Key=%s\nValue=%s", self.key.marshal(), self.value.marshal())
        return self.producer.send(
            topic=self.topic,
            key=self.key.marshal(),
            value=codec.MessageValueCodec(
                self.value.schema).dumps(self.value.marshal()),
            timeout=self.timeout,
        )
