# -*- coding: utf-8 -*-

import os

import avro.datafile
import simplejson

from conveyer import codec
from conveyer import simpleavro


def test_encode_message_key(mocker, key1):
    m_append = mocker.patch.object(avro.datafile.DataFileWriter, "append")
    codec.MessageKeyCodec().dumps(key1)
    m_append.assert_called_once_with(key1)


def test_decode_message_key(encoded_key1):
    decoded_data = codec.MessageKeyCodec().loads(encoded_key1)
    assert decoded_data == [{
        'event_type': 'topic1.test',
        'id': '10043d49-5c1d-4dd8-9986-33688ce50e74',
        'producer_id': 'test_producer',
        'timestamp': '2018-03-05T09:54:57.647685+00:00',
    }]


def test_encode_message_value(mocker, schema1, value1):
    m_append = mocker.patch.object(avro.datafile.DataFileWriter, "append")
    codec.MessageValueCodec(schema1).dumps(value1)
    m_append.assert_called_once_with(value1)


def test_encode_message_value_many_entries(mocker, schema1, value1):
    m_append = mocker.patch.object(avro.datafile.DataFileWriter, "append")
    codec.MessageValueCodec(schema1).dumps([value1, value1])
    m_append.assert_called_with(value1)
    assert m_append.call_count == 2


def test_decode_message_value(schema1, encoded_value1):
    decoded_data = codec.MessageValueCodec(schema1).loads(encoded_value1)
    assert decoded_data == [{'name': 'Alyssa'}]


def test_load_schema_from_dict(schema1):
    schema = simpleavro.load_schema_from_dict(schema1)
    assert schema1 == schema.to_json()


def test_load_schema_from_json_string(schema1):
    schema1_json = simplejson.dumps(schema1)
    schema = simpleavro.load_schema_from_string(schema1_json)
    assert schema1 == schema.to_json()


def test_load_schema_from_filepath(schema1):
    schema = simpleavro.load_schema_from_file(
        os.path.join(os.path.dirname(__file__), "dummy.avsc"))
    assert schema1 == schema.to_json()
