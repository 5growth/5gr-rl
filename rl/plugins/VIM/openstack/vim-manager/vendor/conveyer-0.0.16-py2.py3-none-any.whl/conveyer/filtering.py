# -*- encoding: utf-8 -*-

import re


class MessageFilter:
    """Filter notification messages.

    The MessageFilter class is used to filter notifications that an
    endpoint will received.

    The message can be filtered on different fields:
        producer_id, event_type, metadata and payload.

    The filter is done via a regular expression

    filter_rule =  MessageFilter(
         producer_id='^cluster.*',
         event_type=r"^cluster.event.*",
         meta={'timestamp': 'Aug'},
         payload={'state': '^active$')

    """

    def __init__(self, producer_id=None, event_type=None,
                 meta=None, payload=None):
        self._regex_producer_id = None
        self._regex_event_type = None

        if producer_id is not None:
            self._regex_producer_id = re.compile(producer_id)
        if event_type is not None:
            self._regex_event_type = re.compile(event_type)
        self._regexs_meta = self._build_regex_dict(meta)
        self._regexs_payload = self._build_regex_dict(payload)

    @staticmethod
    def _build_regex_dict(regex_list):
        if regex_list is None:
            return {}
        return dict((k, re.compile(regex_list[k])) for k in regex_list)

    @staticmethod
    def _check_for_single_mismatch(data, regex):
        if regex is None:
            return False
        if not isinstance(data, str):
            return True
        if not regex.match(data):
            return True
        return False

    @classmethod
    def _check_for_mismatch(cls, data, regex):
        if isinstance(regex, dict):
            for k in regex:
                if (k not in data or
                        cls._check_for_single_mismatch(data[k], regex[k])):
                    return True
            return False
        return cls._check_for_single_mismatch(data, regex)

    def match(self, producer_id, event_type, meta, payload):
        if (self._check_for_mismatch(producer_id, self._regex_producer_id) or
                self._check_for_mismatch(event_type, self._regex_event_type) or
                self._check_for_mismatch(meta, self._regexs_meta) or
                self._check_for_mismatch(payload, self._regexs_payload)):
            return False
        return True
